using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    public GameObject player; // we are creating a variable to store the player object reference
    private Vector3 offset= new Vector3(0,7,-10); // we are creating a variable to store the offset value
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void LateUpdate() // LateUpdate is called after all the updates are done. Function of LateUpadte is to update the position of the camera after the player has moved
    {
        transform.position=player.transform.position + offset ; // we are setting the position of the camera to the position of the player plus the offset value
    }
}
