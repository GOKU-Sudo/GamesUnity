using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed=10.0f;
    public float turnSpeed;
    public float horizontalInput;
    public float verticalInput;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // we'll move the vechile forward
        horizontalInput=Input.GetAxis("Horizontal"); // this code is used to get the input from the user. It gets the input from the user and stores it in the variable horizontalInput
        verticalInput=Input.GetAxis("Vertical");

        // transform.Translate(0,0,1); // this code moves the vechile forward in the z-axis 1 unit and it gets updated every frame
        // transform.Translate(Vector3.forward); //above and this code does the same thing. It is used for better understanding for users reading the code

        // transform.Translate(Vector3.forward * Time.deltaTime * speed); // Time.deltaTime is used to make the movement of car frame Independent. It makes the movement of car same on all devices.
        
        transform.Translate(Vector3.forward * Time.deltaTime * speed * verticalInput); // this code is used to move the vechile forward and backward. It is multiplied by verticalInput to get the input from the user and move the vechile forward and backward accordingly.
        // transform.Translate(Vector3.right * Time.deltaTime* turnSpeed * );// we'll move the vechile right.

        // transform.Translate(Vector3.right * Time.deltaTime * turnSpeed * horizontalInput); // this code is used to move the vechile right and left. It is multiplied by horizontalInput to get the input from the user and move the vechile right and left accordingly.
        transform.Rotate(Vector3.up, Time.deltaTime * turnSpeed * horizontalInput); // this code is used to rotate the vechile right and left. It is multiplied by horizontalInput to get the input from the user and rotate the vechile right and left accordingly.
    }
}
